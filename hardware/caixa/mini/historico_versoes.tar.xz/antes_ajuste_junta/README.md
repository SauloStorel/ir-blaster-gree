# Caixa mini — 64 × 45 × 28,4 mm

Versão menor para ESP32 de 52 × 29 mm, receptor IR e emissor IR com seu
pequeno circuito de transistor e resistores. Sem expansão de terminais,
protoboard ou Arduino de testes.

Os módulos IR foram informados como aproximadamente 20 × 20 mm cada.
O receptor KY-022 tem a face óptica normal à placa, enquanto o LED do
KY-005 aponta paralelo à placa. Para ambos olharem para a frente da caixa,
a referência do receptor fica em pé, e a do emissor fica deitada e elevada
acima do ESP32. Há 2 mm entre as faixas laterais das placas e 22 mm entre
os centros dos furos. A base foi compactada
para 64 × 45 mm. As referências incluem somente as placas, com espessura
ilustrativa de 1,6 mm. As formas ópticas são aproximações para mostrar a
direção correta, não modelos dimensionais dos módulos comprados.
Veja `previa_interna.png`.

Abra `caixa_ir_gree_mini.FCStd` no FreeCAD. Os STL `base.stl` e `tampa.stl`
são as peças imprimíveis, em milímetros, já orientadas para a impressão.
`caixa_ir_gree_mini.step` contém a montagem fechada. `previa.png` e
`previa_traseira.png` são renderizações das malhas STL reais, produzidas por
`render_vtk.py` (renderização com iluminação e profundidade) ou
`render_previa.py` (alternativa com Matplotlib); eventual imagem de montagem interna gerada por IA é
apenas uma proposta ilustrativa, não comprovação de encaixe ou esquema elétrico.

## Construção

- Paredes e fundo de 2,4 mm; cantos externos de raio 12 mm.
- Borda superior arredondada em 4,5 mm e inferior em 2 mm. Rebaixo frontal
  mais discreto, com transição de raio 0,2 mm. STL com malha refinada para
  representar as curvas com menor facetamento. As bordas da junta receberam
  raio de 0,15 mm, assim como as bocas dos furos ópticos. A boca do USB foi
  suavizada em 0,2 mm, mantendo as dimensões internas do recorte.
- Fechamento por quatro linguetas de encaixe ocultas na saia da base,
  duas na frente e duas atrás. Sem parafusos ou torres de fixação.
- Cada lingueta tem trecho flexível de 12 mm, espessura de 1 mm e dente
  com rampas superior e inferior. Projeção de 0,6 mm; deslocamento nominal
  para entrada de 0,3 mm. Os dentes se alojam em cavidades internas da
  carcaça, sem furos externos para as travas.
- A saia usa folga de 0,3 mm por lado e junta externa de 0,25 mm.
- Berço integrado à base, com quatro apoios que elevam a placa em 5 mm,
  guias com folga de 0,35 mm por lado e batentes. A placa apoia livremente;
  não há travas nem furação presumida. Confira a posição dos pinos antes
  de montar; suas medidas ainda não foram fornecidas.
- Fundo liso e contínuo, totalmente fechado. Sem furos de parafusos,
  passagens para abraçadeiras ou rebaixos para pés.
- Topo inteiramente liso, sem fendas ou símbolo gravado.
- Sete fendas arredondadas na parede traseira, com 2,4 × 8 mm cada,
  começando a 12 mm do fundo. Os intervalos entre elas medem 1,4 mm.
- Frente rebaixada em 0,5 mm, com somente dois furos circulares simples:
  um de 5,5 mm para o receptor, centralizado em x=21 mm, e um de 5,2 mm
  para o emissor, em x=43 mm. Ambos estão a 20,5 mm do fundo, em uma proposta
  de alinhamento que ainda precisa das medidas reais dos módulos. O furo do
  receptor substitui a antiga abertura alongada. Os diâmetros ainda precisam
  ser conferidos com as faces ópticas dos componentes comprados.
- Entrada micro-USB na lateral curta direita ao olhar de frente para os
  sensores: janela de 10 × 6 mm, cantos de raio 1,2 mm, centralizada nessa
  lateral e a 15,5 mm do fundo. O antigo recorte USB frontal foi fechado.
  A traseira tem somente
  as fendas de ventilação.

## O que já foi confirmado

O envelope retangular de 52 × 29 mm, centralizado acima dos apoios, fica
livre das paredes, torres, saia e guias. Há cerca de 18,6 mm de altura disponível
acima dos apoios. Base e carcaça são sólidos únicos válidos, sem interferência
entre elas; as duas malhas STL são fechadas. Resultados em `validacao.json`.
A seção do fundo foi conferida: somente o contorno externo, sem furos.
Os dentes ficam livres nas cavidades quando fechados; foi conferido o
espaço de entrada com deslocamento radial nominal de 0,31 mm. Isso é uma
verificação geométrica e não uma simulação mecânica da flexão do PLA.
Veja `previa_fundo.png` e `previa_apoio.png`.

A altura real da placa com seus conectores não foi informada. O receptor,
o circuito emissor e o percurso do cabo ainda precisam de conferência física.
As referências IR não colidem com a caixa nem com a referência da PCB do
ESP32 de 1,6 mm. O emissor deitado tem sua PCB a 16,4 mm do fundo, com
7,4 mm entre a face superior da PCB do ESP32 e a face inferior da PCB do
emissor. Essa folga ainda precisa acomodar os componentes reais do ESP32.
O berço inferior apoia somente o ESP32. A fixação elevada do emissor ainda
precisa ser dimensionada com as medidas e os pinos reais do módulo; a
referência elevada não é um suporte imprimível. Isso não valida a montagem
completa nem o alinhamento exato da face óptica com os furos.
As aberturas são passagens genéricas e não berços específicos dos módulos.
A entrada lateral prevê um conector micro-USB de painel ou pequena placa
adaptadora ligada à alimentação do ESP32. Ela não coincide com o USB nativo
na ponta da placa. O conector extra não foi escolhido nem dimensionado;
a janela de 10 × 6 mm é uma previsão inicial, sem berço específico. Confira
as medidas e a fixação do conector e do plugue antes de imprimir.

## Impressão

Ponto de partida: PLA, bico 0,4 mm, camada 0,20 mm, quatro perímetros,
cinco camadas de topo/fundo e 15–20% de preenchimento. Use as temperaturas
do fabricante. Base com fundo na mesa; carcaça com topo externo na mesa,
conforme orientação já salva no STL. Confira primeira camada e pequenas
pontes dos furos no fatiador. Não foi feita impressão de teste.

Antes da caixa completa, imprima `teste_encaixe_base.stl` e
`teste_encaixe_parede.stl`: são um trecho da base e da parede com uma trava,
para conferir o ajuste na sua impressora. As faces externas dessas amostras
ficam alinhadas durante o teste; a parede desliza por fora da saia da base.
As amostras verificam a tolerância local, não a força total das quatro travas.
Confira os pequenos vãos das linguetas e a região das rampas no fatiador;
evite suportes dentro dos vãos das travas. A base imprime com o fundo na mesa.

Feche alinhando a saia e pressionando os quatro pontos até assentarem.
Para abrir, separe gradualmente pela junta, sem torcer uma lingueta isolada.
As rampas de saída ajudam a soltar, mas a retenção e a resistência a aberturas
repetidas ainda precisam de ensaio físico. O encaixe foi pensado para abertura
ocasional. As dimensões das linguetas ficam nas constantes `SNAP_*` do gerador.

Os anúncios enviados mostram KY-022/VS1838B e KY-005. A medida de
7,4 × 6,4 × 5,1 mm do anúncio do receptor parece descrever o encapsulamento
do sensor; não foi adotada como dimensão da placa inteira. As referências
de PCB continuam com os 20 × 20 mm aproximados informados pelo usuário.
Os furos de 5,5 e 5,2 mm são previsões para expor a parte óptica, sem passar
a placa ou o corpo inteiro. Ainda precisam de conferência física.

A planilha no FreeCAD é uma referência. Para regenerar, altere as constantes
em `gerar_caixa.py` e execute `python hardware/caixa/mini/gerar_caixa.py`.
As referências verdes do ESP32 e dos dois módulos IR são ilustrativas e
devem permanecer fora do fatiamento. Oculte a carcaça e mostre essas
referências na árvore do FreeCAD para examinar a proposta interna.
