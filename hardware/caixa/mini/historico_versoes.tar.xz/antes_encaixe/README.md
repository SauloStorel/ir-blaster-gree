# Caixa mini — 70 × 45 × 28,4 mm

Versão menor para ESP32 de 52 × 29 mm, receptor IR e emissor IR com seu
pequeno circuito de transistor e resistores. Sem expansão de terminais,
protoboard ou Arduino de testes.

Os módulos IR foram informados como aproximadamente 20 × 20 mm cada.
Foram colocadas referências dessas placas em pé na frente, lado a lado,
com 4 mm entre elas. A altura externa passou de 25,4 para 28,4 mm para
deixar 2,6 mm acima dessas referências. O comprimento e a largura continuam
70 × 45 mm. As referências incluem somente as placas, com espessura
ilustrativa de 1,6 mm; componentes, conectores e pinos não foram medidos.

Abra `caixa_ir_gree_mini.FCStd` no FreeCAD. Os STL `base.stl` e `tampa.stl`
são as peças imprimíveis, em milímetros, já orientadas para a impressão.
`caixa_ir_gree_mini.step` contém a montagem fechada. `previa.png` e
`previa_traseira.png` são renderizações das malhas STL reais, produzidas por
`render_previa.py`; eventual imagem de montagem interna gerada por IA é
apenas uma proposta ilustrativa, não comprovação de encaixe ou esquema elétrico.

## Construção

- Paredes e fundo de 2,4 mm; cantos externos de raio 7 mm.
- Duas torres nas bordas longas, afastadas dos sensores e do micro-USB lateral.
- Dois parafusos inferiores ocultos, autoatarraxantes de aproximadamente
  2,9 × 10 mm, cabeça escareada de 90°. Confirme piloto e cabeça antes de montar.
- Passantes de 3,3 mm, pilotos cegos de 2,4 mm e escareados de 6,2 mm.
- A saia usa folga de 0,3 mm por lado e junta externa de 0,35 mm.
- Berço integrado à base, com quatro apoios que elevam a placa em 5 mm,
  guias com folga de 0,35 mm por lado e batentes. A placa apoia livremente;
  não há travas nem furação presumida. Confira a posição dos pinos antes
  de montar; suas medidas ainda não foram fornecidas.
- Fundo liso e contínuo, com somente dois furos escareados para fechar a
  caixa. Sem passagens para abraçadeiras ou rebaixos para pés.
- Topo inteiramente liso, sem fendas ou símbolo gravado.
- Sete fendas arredondadas na parede traseira, com 2,4 × 8 mm cada,
  começando a 12 mm do fundo. Os intervalos entre elas medem 1,4 mm.
- Frente rebaixada em 0,65 mm, com somente dois furos circulares simples:
  um de 8 mm para o receptor, centralizado em x=24 mm, e um de 5,4 mm
  para o emissor, em x=48 mm. Ambos estão a 15,5 mm do fundo. O furo do
  receptor substitui a antiga abertura alongada. Os diâmetros ainda precisam
  ser conferidos com as faces ópticas dos componentes comprados.
- Entrada micro-USB na lateral curta direita ao olhar de frente para os
  sensores: janela de 10 × 6 mm, cantos de raio 0,8 mm, centralizada nessa
  lateral e a 15,5 mm do fundo. O antigo recorte USB frontal foi fechado.
  A traseira tem somente
  as fendas de ventilação.

## O que já foi confirmado

O envelope retangular de 52 × 29 mm, centralizado acima dos apoios, fica
livre das paredes, torres, saia e guias. Há cerca de 18,6 mm de altura disponível
acima dos apoios. Base e carcaça são sólidos únicos válidos, sem interferência
entre elas; as duas malhas STL são fechadas. Resultados em `validacao.json`.
A seção do fundo foi conferida: somente o contorno externo e os dois furos
de fechamento. Veja `previa_fundo.png` e `previa_apoio.png`.

A altura real da placa com seus conectores não foi informada. O receptor,
o circuito emissor e o percurso do cabo ainda precisam de conferência física.
As duas referências das placas IR de 20 × 20 mm não colidem com a caixa
nem com o envelope da placa ESP32. Isso não valida a projeção dos sensores,
LED, pinos e fios, que pode ultrapassar as referências das placas.
As aberturas são passagens genéricas e não berços específicos dos módulos.
A entrada lateral prevê um conector micro-USB de painel ou pequena placa
adaptadora ligada à alimentação do ESP32. Ela não coincide com o USB nativo
na ponta da placa. O conector extra não foi escolhido nem dimensionado;
a janela de 10 × 6 mm é uma previsão inicial, sem berço específico. Confira
as medidas e a fixação do conector e do plugue antes de imprimir.

## Impressão

Ponto de partida: PLA, bico 0,4 mm, camada 0,20 mm, quatro perímetros,
cinco camadas de topo/fundo e 15–20% de preenchimento. Use as temperaturas
do fabricante. Base com fundo na mesa; carcaça com topo externo na mesa,
conforme orientação já salva no STL. Confira primeira camada e pequenas
pontes dos furos no fatiador. Não foi feita impressão de teste.

A planilha no FreeCAD é uma referência. Para regenerar, altere as constantes
em `gerar_caixa.py` e execute `python hardware/caixa/mini/gerar_caixa.py`.
As referências verdes do ESP32 e dos dois módulos IR são ilustrativas e
devem permanecer fora do fatiamento. Oculte a carcaça e mostre essas
referências na árvore do FreeCAD para examinar a proposta interna.
