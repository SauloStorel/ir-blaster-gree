# Caixa mini — 64 × 63 × 35,8 mm

## Imprimir

Os STL já estão orientados. PLA, bico 0,4 mm, camada 0,2 mm, 4 perímetros,
15–20% de preenchimento e ventoinha ligada.

1. `teste_encaixe_base.stl` + `teste_encaixe_parede.stl` (minutos): encaixe
   a parede na base. Se a trava ficar dura demais ou frouxa, ajuste as
   constantes `SNAP_*` ou `GAP` e gere de novo.
2. `base.stl`: fundo na mesa.
3. `tampa.stl`: topo na mesa.

Confira no fatiador as ranhuras dos trilhos do emissor: o teto de cada
ranhura é um balanço de 2 mm, que costuma sair sem suporte em PLA.

## O que vai dentro

ESP32 DevKit de 30 pinos (52 × 29 mm) e o emissor IR KY-005, ligados por
jumpers Dupont fêmea-fêmea, sem solda. Sem receptor IR: o KY-022 serviu só
para ler o controle original (`firmware/receptor_ir/`).

- **ESP32 em pé**, encostado na traseira, com os componentes virados para
  trás e os pinos para a frente. Duas colunas com ranhura vertical seguram
  as pontas curtas da placa, fora das barras de pinos; a placa apoia 1 mm
  acima do fundo e o teto impede que ela saia para cima.
- A **fileira de cima** é a que tem 3V3, GND e D4, perto do USB: é nela que
  entram os jumpers. Por isso o micro-USB fica na **lateral esquerda**, ao
  olhar a caixa pela frente.
- **Emissor deitado na base**, à frente do ESP32, em dois trilhos com
  batente frontal. A placa entra por trás, com o LED à frente, até o batente.
  O LED fica 0,3 mm atrás da parede, alinhado ao furo, porque a carcaça
  desce na vertical ao fechar.
- Os jumpers do emissor saem para trás, passam acima da fileira de baixo do
  ESP32 e têm espaço para o fio dobrar antes da placa.

Veja `previa_interna.png`. Montagem: deslize o emissor nos trilhos, encaixe
o ESP32 nas colunas, ligue os jumpers (sinal do emissor no D4, `–` no GND),
acomode as sobras de fio no espaço da frente e feche a carcaça pressionando
os quatro pontos das travas até assentarem.

## Construção

- Paredes e fundo de 2,4 mm; cantos externos de raio 6 mm, borda superior
  arredondada em 2 mm e inferior em 1,2 mm.
- Fechamento por quatro linguetas ocultas na saia da base, duas na frente e
  duas atrás, sem parafusos. Cada uma tem trecho flexível de 12 mm, 1 mm de
  espessura e dente de 0,6 mm com rampas de entrada e saída.
- Profundidade calculada a partir da corrente do emissor (LED, PCB de
  18,5 mm, capa Dupont de 14 mm e 4 mm para o fio dobrar) até a face dos
  pinos do ESP32. Atrás da placa sobram 10,5 mm, para os componentes e para
  a janela do USB caber no trecho reto da lateral, antes do canto curvo.
- Frente com faixa rebaixada em 0,5 mm e um único furo de 5,2 mm para o
  LED, centralizado e a 14,6 mm do fundo.
- Micro-USB na lateral esquerda: janela de 9 × 12 mm, centralizada no
  conector, para a borracha do plugue (~7,5 × 11 mm) entrar até a placa.
- Sete fendas de ventilação na traseira. Topo e fundo lisos e fechados.

## O que já foi confirmado

O gerador confere que base e carcaça são sólidos válidos e sem
interferência, com malhas fechadas, contorno do fundo sem furos, travas
livres nas cavidades e espaço de entrada dos dentes. Também confere, com
referências simplificadas, que nada encosta na caixa nem um no outro: PCB do
ESP32, componentes atrás dela (até 3,5 mm), as duas barras de pinos, os
jumpers do ESP32 (1,2 mm abaixo do teto), o emissor, o LED e os jumpers
dele, além do plugue micro-USB. Deslocar o ESP32 ou o emissor 0,4 mm faz a
placa encontrar a ranhura, o trilho ou o batente. Resultados em
`validacao.json`. Nada disso substitui o teste físico.

**Antes de imprimir, meça com paquímetro:**

- o comprimento da capa dos seus jumpers Dupont: o projeto supõe 14 mm
  (`DUPONT_LENGTH`);
- a altura dos componentes atrás do ESP32 (módulo, botões, USB): supõe até
  3,5 mm, e nada nas pontas curtas abaixo de 4 mm, onde fica a ranhura de trás;
- quanto os pinos do ESP32 saem da placa, contando o espaçador: supõe 8,5 mm;
- a placa do KY-005 (supõe 15 × 18,5 mm; os trilhos aceitam 14 a 16 mm de
  largura) e onde o LED fica em relação à borda;
- a borracha do cabo micro-USB: a passagem aceita até ~8,5 × 11,5 mm.

## Arquivos

- `gerar_caixa.py`: fonte; altere as constantes e execute
  `python hardware/caixa/mini/gerar_caixa.py`.
- `base.stl`, `tampa.stl` e as amostras de encaixe: peças de impressão.
- `caixa_ir_gree_mini.FCStd`: montagem no FreeCAD, com referências verdes
  ocultas do ESP32, do emissor e dos jumpers (não imprimir).
- `caixa_ir_gree_mini.step`: base e carcaça para outros programas CAD.
- `previa*.png`: renderizações das malhas reais por `render_vtk.py`.
- `historico_versoes.tar.xz`: versões anteriores, cada uma numa pasta
  `antes_*`. A mais recente é `antes_esp32_em_pe` (64 × 45 × 32,9 mm, ESP32
  deitado com os pinos para baixo e emissor nos trilhos do teto).

As imagens geradas por IA (`proposta_interna*.png`, `visualizacao_fisica.png`)
são de versões anteriores e não mostram este arranjo.
