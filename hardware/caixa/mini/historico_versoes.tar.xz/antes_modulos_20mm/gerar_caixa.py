"""Caixa mini: ESP32 de 52 × 29 mm, micro-USB na lateral direita."""
import sys, json
from pathlib import Path
sys.path.insert(0, '/usr/lib/freecad/lib')
import FreeCAD as App
import Part, MeshPart, Import
V=App.Vector
OUT=Path(__file__).resolve().parent
L,W,H=70.,45.,25.4
T=2.4
R=7.
SEAM=8.
GAP=.3

def rr(l,w,h,r,x=0,y=0,z=0):
    b=Part.makeBox(l,w,h,V(x,y,z))
    return b.makeFillet(r,[e for e in b.Edges if e.BoundBox.ZLength>h-.001])

def edge_round(s,z,r):
    return s.makeFillet(r,[e for e in s.Edges if abs(e.BoundBox.ZMin-z)<1e-5 and abs(e.BoundBox.ZMax-z)<1e-5])

# Todos os sólidos são construídos primeiro na posição de montagem.
outer=edge_round(rr(L,W,H-SEAM,R,z=SEAM),H,2.)
shell=outer.cut(rr(L-2*T,W-2*T,H-T+1,R-T,T,T,-1))
tray=edge_round(rr(L,W,SEAM-.35,R),0,1.2)
tray=tray.cut(rr(L-2*T,W-2*T,H,R-T,T,T,T))
# Saia inferior encaixada por dentro da carcaça: vão visual de 0,35 mm.
inset=T+GAP
lip=rr(L-2*inset,W-2*inset,3.35,R-inset,inset,inset,SEAM-.35)
lip=lip.cut(rr(L-2*(inset+1.6),W-2*(inset+1.6),5,R-inset-1.6,inset+1.6,inset+1.6,SEAM-1))
shoulder=rr(L-3.8,W-3.8,2.1,R-1.9,1.9,1.9,SEAM-2.35)
shoulder=shoulder.cut(rr(L-2*(inset+1.6),W-2*(inset+1.6),3,R-inset-1.6,inset+1.6,inset+1.6,SEAM-2.5))
lip=lip.fuse(shoulder)
centers=[(14,4.2),(14,W-4.2)]
for x,y in centers:
    lip=lip.cut(Part.makeCylinder(3.9,7,V(x,y,SEAM-3)))
tray=tray.fuse(lip)
# Parafusos entram pelo fundo e prendem torres integradas na carcaça superior.
for x,y in centers:
    shell=shell.fuse(Part.makeCylinder(3.3,H-T-(T+.3),V(x,y,T+.3)))
    shell=shell.cut(Part.makeCylinder(1.2,12,V(x,y,T+.3)))
    tray=tray.cut(Part.makeCylinder(3.6,H,V(x,y,T+.2)))
    tray=tray.cut(Part.makeCylinder(1.65,T+2,V(x,y,-1)))
    tray=tray.cut(Part.makeCone(3.1,1.65,1.45,V(x,y,0)))
# Frente: nicho raso alongado agrupa as duas aberturas ópticas.
# Cápsulas no plano XZ, extrudadas em Y.
def front_slot(width,height,depth,x,z,y=-1):
    s=rr(width,height,depth,height/2-.01)
    s.rotate(V(),V(1,0,0),90)
    s.translate(V(x,y+depth,z))
    return s
shell=shell.cut(front_slot(34,11,1.65,L/2-17,10))
shell=shell.cut(front_slot(14,8,5,L/2-14,11.5))
shell=shell.cut(Part.makeCylinder(2.7,5,V(L/2+10,-1,15.5),V(0,1,0)))
# Micro-USB na lateral curta direita ao olhar diretamente para os sensores.
# Prevê conector de painel/breakout separado; o USB nativo da placa fica na ponta.
# Recorte inicial com folga: conferir o corpo do conector comprado.
USB_WIDTH, USB_HEIGHT, USB_BOTTOM, USB_CENTER_Y = 10., 6., 12.5, W/2
usb_cut=rr(USB_WIDTH,USB_HEIGHT,5,.8)
usb_cut.rotate(V(),V(1,1,1),120)
usb_cut.translate(V(L-4,USB_CENTER_Y-USB_WIDTH/2,USB_BOTTOM))
shell=shell.cut(usb_cut)
# Topo inteiramente liso; sete fendas verticais na parede traseira.
# Mantidas acima da saia e longe da torre de parafuso traseira.
VENT_WIDTH, VENT_HEIGHT, VENT_BOTTOM, VENT_PITCH = 2.4, 8., 12., 3.8
vent_centers=[]
for i in range(7):
    x=L/2+(i-3)*VENT_PITCH
    vent_centers.append(x)
    vent=rr(VENT_WIDTH,VENT_HEIGHT,5,1.19)
    vent.rotate(V(),V(1,0,0),90)
    vent.translate(V(x-VENT_WIDTH/2,W+1,VENT_BOTTOM))
    shell=shell.cut(vent)
# Passagens para abraçadeiras e apoios isolantes de 1 mm sob a eletrônica.
for x in (21,L-21):
    for y in (6,W-6):
        tray=tray.cut(rr(8,3,T+2,1,x-4,y-1.5,-1))
    for y in (14,W-14):
        tray=tray.fuse(rr(10,5,1,2,x-5,y-2.5,T))
# Rebaixos para pés autoadesivos de 8 mm: opcionais, não fazem parte do STL.
for x in (18,L-18):
    for y in (12,W-12):
        tray=tray.cut(Part.makeCylinder(4.2,.8,V(x,y,0)))
tray=tray.removeSplitter()
shell=shell.removeSplitter()
checks={'interferencia_mm3':tray.common(shell).Volume,'dimensoes_externas_mm':[L,W,H],
        'microusb_lateral_direita':{'face':'x=70','centro_y_mm':USB_CENTER_Y,
        'largura_mm':USB_WIDTH,'altura_mm':USB_HEIGHT,'altura_inferior_mm':USB_BOTTOM,
        'conector_painel_separado':True},'abertura_usb_frontal':False,'abertura_cabo_traseira':False,
        'topo_liso':True,'ventilacao_traseira':{'quantidade':7,'largura_mm':VENT_WIDTH,
        'altura_mm':VENT_HEIGHT,'altura_inferior_mm':VENT_BOTTOM}}
assert checks['interferencia_mm3']<.001, checks
assert not shell.isInside(V(L-T/2,USB_CENTER_Y,USB_BOTTOM+USB_HEIGHT/2),1e-6,True)
assert shell.isInside(V(57.5,T/2,15.5),1e-6,True), 'Recorte USB frontal antigo deve estar fechado'
assert shell.isInside(V(T/2,W/2,12),1e-6,True), 'Lateral esquerda deve estar fechada'
# Confere a continuidade do topo plano e a abertura efetiva das fendas traseiras.
roof_probe=Part.makeBox(L-2*R,W-2*R,.3,V(R,R,H-.3))
assert abs(roof_probe.common(shell).Volume-roof_probe.Volume)<.001
for x in vent_centers:
    assert not shell.isInside(V(x,W-T/2,VENT_BOTTOM+VENT_HEIGHT/2),1e-6,True)
# Envelope retangular acima dos apoios. Só comprimento/largura foram medidos.
# A altura é a capacidade disponível, não uma medida informada do ESP32.
board_z=T+1+.01
board_height=H-T-board_z-.01
board_envelope=Part.makeBox(52,29,board_height,V((L-52)/2,(W-29)/2,board_z))
checks['esp32_mm']=[52,29]
checks['altura_disponivel_sobre_apoios_mm']=round(board_height,2)
checks['interferencia_envelope_esp32_mm3']=board_envelope.common(tray.fuse(shell)).Volume
assert checks['interferencia_envelope_esp32_mm3']<.001, checks
# STLs orientados para impressão: exterior de cada peça na mesa.
print_shell=shell.copy()
print_shell.rotate(V(0,W/2,0),V(1,0,0),180)
print_shell.translate(V(0,0,H))
for name,shape in [('base',tray),('tampa',print_shell)]:
    assert shape.isValid() and len(shape.Solids)==1,name
    mesh=MeshPart.meshFromShape(Shape=shape,LinearDeflection=.05,AngularDeflection=.12,Relative=False)
    assert mesh.isSolid(),name
    mesh.write(str(OUT/(name+'.stl')))
    checks[name]={'solido_valido':True,'malha_fechada':True,'volume_mm3':round(shape.Volume,2),'triangulos':mesh.CountFacets}
# Documento em montagem fechada e uma vista explodida para inspecionar.
name='Caixa_IR_Gree_Mini'
if name in App.listDocuments():
    raise RuntimeError('Feche o documento compacto antes de regenerar para não perder alterações.')
doc=App.newDocument(name)
for name,label,shape in [('Base','Bandeja inferior · parafusos ocultos',tray),('Tampa','Carcaça superior · PLA carmesim',shell)]:
    obj=doc.addObject('PartDesign::Feature',name)
    obj.Label=label
    obj.Shape=shape.cleaned()
    obj.addProperty('App::PropertyString','Fonte').Fonte='gerar_caixa.py — dimensões ajustáveis no script'
    if App.GuiUp:
        obj.Visibility=True
        obj.ViewObject.ShapeColor=(.62,.035,.13)
        obj.ViewObject.LineColor=(.22,.025,.05)
        obj.ViewObject.DisplayMode='Flat Lines'
        obj.ViewObject.LineWidth=1.
        obj.ViewObject.AngularDeflection=10
        obj.ViewObject.Deviation=.1
sheet=doc.addObject('Spreadsheet::Sheet','Medidas')
for i,(key,val) in enumerate([('Comprimento',L),('Largura',W),('Altura',H),('Parede',T),('Raio',R),('Junta inferior',SEAM),('Folga por lado',GAP)],1):
    sheet.set(f'A{i}',key);sheet.set(f'B{i}',str(val)+' mm')
sheet.setColumnWidth('A',180)
footprint=doc.addObject('PartDesign::Feature','ReferenciaESP32')
footprint.Label='Referência 52 × 29 mm · altura real não informada · não imprimir'
footprint.Shape=Part.makeBox(52,29,1.6,V((L-52)/2,(W-29)/2,T+1)).cleaned()
if App.GuiUp:
    footprint.ViewObject.ShapeColor=(.1,.45,.25)
    footprint.Visibility=False
doc.recompute()
Import.export([doc.getObject('Base'),doc.getObject('Tampa')],str(OUT/'caixa_ir_gree_mini.step'))
if App.GuiUp:
    import FreeCADGui as Gui
    Gui.activeDocument().activeView().viewAxonometric()
    Gui.activeDocument().activeView().fitAll()
doc.recompute()
doc.saveAs(str(OUT/'caixa_ir_gree_mini.FCStd'))
(OUT/'validacao.json').write_text(json.dumps(checks,indent=2)+'\n')
print(json.dumps(checks,indent=2))
