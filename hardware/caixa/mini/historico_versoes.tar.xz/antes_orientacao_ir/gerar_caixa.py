"""Caixa mini: ESP32 de 52 × 29 mm, micro-USB na lateral direita."""
import sys, json
from pathlib import Path
sys.path.insert(0, '/usr/lib/freecad/lib')
import FreeCAD as App
import Part, MeshPart, Import
V=App.Vector
OUT=Path(__file__).resolve().parent
L,W,H=64.,45.,28.4
T=2.4
R=8.
SEAM=8.
GAP=.3
JOINT_GAP=.25
BOARD_L, BOARD_W = 52., 29.
SUPPORT_HEIGHT, GUIDE_CLEARANCE, GUIDE_EXTRA = 5., .35, 2.5
BX, BY = (L-BOARD_L)/2, (W-BOARD_W)/2
SENSOR_SIZE, SENSOR_GAP = 20., 2.
SENSOR_LEFT=(L-(2*SENSOR_SIZE+SENSOR_GAP))/2
RECEIVER_X=SENSOR_LEFT+SENSOR_SIZE/2
EMITTER_X=RECEIVER_X+SENSOR_SIZE+SENSOR_GAP

def rr(l,w,h,r,x=0,y=0,z=0):
    b=Part.makeBox(l,w,h,V(x,y,z))
    return b.makeFillet(r,[e for e in b.Edges if e.BoundBox.ZLength>h-.001])

def edge_round(s,z,r):
    return s.makeFillet(r,[e for e in s.Edges if abs(e.BoundBox.ZMin-z)<1e-5 and abs(e.BoundBox.ZMax-z)<1e-5])

# Todos os sólidos são construídos primeiro na posição de montagem.
outer=edge_round(rr(L,W,H-SEAM,R,z=SEAM),H,3.)
shell=outer.cut(rr(L-2*T,W-2*T,H-T+1,R-T,T,T,-1))
tray=edge_round(rr(L,W,SEAM-JOINT_GAP,R),0,1.5)
tray=tray.cut(rr(L-2*T,W-2*T,H,R-T,T,T,T))
# Saia inferior encaixada por dentro da carcaça: junta externa de 0,25 mm.
inset=T+GAP
lip=rr(L-2*inset,W-2*inset,3.35,R-inset,inset,inset,SEAM-JOINT_GAP)
lip=lip.cut(rr(L-2*(inset+1.6),W-2*(inset+1.6),5,R-inset-1.6,inset+1.6,inset+1.6,SEAM-1))
shoulder=rr(L-3.8,W-3.8,2.1,R-1.9,1.9,1.9,SEAM-2-JOINT_GAP)
shoulder=shoulder.cut(rr(L-2*(inset+1.6),W-2*(inset+1.6),3,R-inset-1.6,inset+1.6,inset+1.6,SEAM-2.5))
lip=lip.fuse(shoulder)
tray=tray.fuse(lip)
# Quatro linguetas horizontais flexíveis na saia, com dentes rampados.
# Sem torres ou furos de parafuso. Cavidades ficam ocultas na parede interna.
SNAP_LENGTH, SNAP_THICKNESS, SNAP_PROJECTION = 12., 1., .6
snap_teeth=[]
snap_pockets=[]
for rear in (False,True):
    for x in (20.,42.):
        # Cada lingueta fica presa somente pela extremidade x+12.
        outer_y=inset if not rear else W-inset-1.6
        bottom_slot=Part.makeBox(SNAP_LENGTH+.5,1.8,.95,V(x-.5,outer_y-.1,7.25))
        tip_slot=Part.makeBox(.55,1.8,4,V(x-.55,outer_y-.1,7.2))
        relief_y=inset+SNAP_THICKNESS if not rear else W-inset-1.7
        inner_relief=Part.makeBox(SNAP_LENGTH,.7,3.2,V(x,relief_y,8.15))
        tray=tray.cut(bottom_slot).cut(tip_slot).cut(inner_relief)
        # Rampas superior e inferior permitem encaixar e soltar com cuidado.
        profile=[(inset,8.8),(inset-SNAP_PROJECTION,9.2),
                 (inset-SNAP_PROJECTION,9.5),(inset,10.7)]
        points=[V(x+1,W-y if rear else y,z) for y,z in profile]
        points.append(points[0])
        tooth=Part.Face(Part.makePolygon(points)).extrude(V(4,0,0))
        tray=tray.fuse(tooth)
        snap_teeth.append(tooth)
        pocket_y=W-2.5 if rear else 1.6
        pocket=Part.makeBox(4.6,.9,2.7,V(x+.7,pocket_y,8.5))
        shell=shell.cut(pocket)
        snap_pockets.append(pocket)
# Frente: rebaixo externo raso e somente um furo circular por sensor.
# Cápsulas no plano XZ, extrudadas em Y.
def front_slot(width,height,depth,x,z,y=-1):
    s=rr(width,height,depth,height/2-.01)
    s.rotate(V(),V(1,0,0),90)
    s.translate(V(x,y+depth,z))
    return s
shell=shell.cut(front_slot(38,10,1.5,(L-38)/2,10.5))
RECEIVER_DIAMETER, EMITTER_DIAMETER = 5.5, 5.2
shell=shell.cut(Part.makeCylinder(RECEIVER_DIAMETER/2,5,V(RECEIVER_X,-1,15.5),V(0,1,0)))
shell=shell.cut(Part.makeCylinder(EMITTER_DIAMETER/2,5,V(EMITTER_X,-1,15.5),V(0,1,0)))
# Transição suave somente no contorno do rebaixo; os furos continuam simples.
panel_edges=[e for e in shell.Edges if abs(e.BoundBox.YMin-.5)<1e-6
             and abs(e.BoundBox.YMax-.5)<1e-6
             and (e.BoundBox.XMin<(L-38)/2+.01
                  or e.BoundBox.XMax>(L+38)/2-.01
                  or e.BoundBox.ZMin<10.51 or e.BoundBox.ZMax>20.49)]
assert len(panel_edges)==8
shell=shell.makeFillet(.2,panel_edges)
# Micro-USB na lateral curta direita ao olhar diretamente para os sensores.
# Prevê conector de painel/breakout separado; o USB nativo da placa fica na ponta.
# Recorte inicial com folga: conferir o corpo do conector comprado.
USB_WIDTH, USB_HEIGHT, USB_BOTTOM, USB_CENTER_Y = 10., 6., 12.5, W/2
usb_cut=rr(USB_WIDTH,USB_HEIGHT,5,1.2)
usb_cut.rotate(V(),V(1,1,1),120)
usb_cut.translate(V(L-4,USB_CENTER_Y-USB_WIDTH/2,USB_BOTTOM))
shell=shell.cut(usb_cut)
# Topo inteiramente liso; sete fendas verticais na parede traseira.
# Mantidas acima da saia e longe da torre de parafuso traseira.
VENT_WIDTH, VENT_HEIGHT, VENT_BOTTOM, VENT_PITCH = 2.4, 8., 12., 3.8
vent_centers=[]
for i in range(7):
    x=L/2+(i-3)*VENT_PITCH
    vent_centers.append(x)
    vent=rr(VENT_WIDTH,VENT_HEIGHT,5,1.19)
    vent.rotate(V(),V(1,0,0),90)
    vent.translate(V(x-VENT_WIDTH/2,W+1,VENT_BOTTOM))
    shell=shell.cut(vent)
# Fundo contínuo: sem passagens de abraçadeira ou rebaixos para pés.
# Berço integrado à base: quatro apoios de 5 mm sob as extremidades da PCB.
# Centro e faixas dos headers ficam livres; as posições dos pinos são desconhecidas.
for x in (BX+.5, BX+BOARD_L-3.5):
    for y in (15.,26.):
        tray=tray.fuse(rr(3,4,SUPPORT_HEIGHT,.6,x,y,T))
# Guias laterais com folga, abertas no meio para não bloquear o USB da placa.
guide_height=SUPPORT_HEIGHT+GUIDE_EXTRA
for x in (BX-GUIDE_CLEARANCE-1.5,BX+BOARD_L+GUIDE_CLEARANCE):
    for y in (14.,25.):
        tray=tray.fuse(rr(1.5,6,guide_height,.7,x,y,T))
# Batentes frontais fora das placas IR de 20 × 20 mm.
for x in (BX+1,BX+BOARD_L-4):
    tray=tray.fuse(rr(3,1.5,guide_height,.7,x,BY-GUIDE_CLEARANCE-1.5,T))
for x in (BX+15,BX+36):
    tray=tray.fuse(rr(6,1.5,guide_height,.7,x,BY+BOARD_W+GUIDE_CLEARANCE,T))
tray=tray.removeSplitter()
shell=shell.removeSplitter()
checks={'interferencia_mm3':tray.common(shell).Volume,'dimensoes_externas_mm':[L,W,H],
        'microusb_lateral_direita':{'face':f'x={L:g}','centro_y_mm':USB_CENTER_Y,
        'largura_mm':USB_WIDTH,'altura_mm':USB_HEIGHT,'altura_inferior_mm':USB_BOTTOM,
        'conector_painel_separado':True},'abertura_usb_frontal':False,'abertura_cabo_traseira':False,
        'topo_liso':True,'ventilacao_traseira':{'quantidade':7,'largura_mm':VENT_WIDTH,
        'altura_mm':VENT_HEIGHT,'altura_inferior_mm':VENT_BOTTOM},
        'aberturas_ir_frontais':{'quantidade':2,'rebaixo_compartilhado':True,
        'profundidade_rebaixo_mm':.5,'receptor_diametro_mm':RECEIVER_DIAMETER,
        'emissor_diametro_mm':EMITTER_DIAMETER,'distancia_centros_mm':EMITTER_X-RECEIVER_X},
        'acabamento':{'raio_cantos_mm':R,'raio_borda_superior_mm':3.,
        'raio_borda_inferior_mm':1.5,'raio_rebaixo_mm':.2,'junta_mm':JOINT_GAP}}
checks['fundo']={'furos_parafusos':0,'passagens_abracadeiras':0,'rebaixos_pes':0,
 'espessura_mm':T}
checks['fechamento']={'tipo':'encaixe com linguetas rampadas','travas':4,
 'comprimento_flexivel_mm':SNAP_LENGTH,'espessura_lingueta_mm':SNAP_THICKNESS,
 'projecao_dente_mm':SNAP_PROJECTION,'deflexao_nominal_montagem_mm':SNAP_PROJECTION-GAP,
 'ensaio_fisico_realizado':False}
# A seção próxima da face externa deve ser um único contorno sem furos.
bottom_wires=tray.slice(V(0,0,1),.1)
assert len(bottom_wires)==1 and bottom_wires[0].isClosed()
for tooth,pocket in zip(snap_teeth,snap_pockets):
    assert tooth.common(shell).Volume<.001
    assert tooth.common(pocket).Volume>.01
# Comprova a folga nominal de entrada dos dentes com deslocamento radial.
for i,tooth in enumerate(snap_teeth):
    flexed=tooth.copy()
    flexed.translate(V(0,-.31 if i>=2 else .31,0))
    for offset in (-4.,-2.,0.):
        moved=flexed.copy()
        moved.translate(V(0,0,offset))
        assert moved.common(shell).Volume<.001
assert checks['interferencia_mm3']<.001, checks
assert not shell.isInside(V(L-T/2,USB_CENTER_Y,USB_BOTTOM+USB_HEIGHT/2),1e-6,True)
assert shell.isInside(V(L/2,T/2,15.5),1e-6,True), 'Material deve separar os dois sensores'
assert shell.isInside(V(T/2,W/2,12),1e-6,True), 'Lateral esquerda deve estar fechada'
# Confere a continuidade do topo plano e a abertura efetiva das fendas traseiras.
roof_probe=Part.makeBox(L-2*R,W-2*R,.3,V(R,R,H-.3))
assert abs(roof_probe.common(shell).Volume-roof_probe.Volume)<.001
for x in vent_centers:
    assert not shell.isInside(V(x,W-T/2,VENT_BOTTOM+VENT_HEIGHT/2),1e-6,True)
# Envelope retangular acima dos apoios. Só comprimento/largura foram medidos.
# A altura é a capacidade disponível, não uma medida informada do ESP32.
board_z=T+SUPPORT_HEIGHT+.01
board_height=H-T-board_z-.01
board_envelope=Part.makeBox(52,29,board_height,V((L-52)/2,(W-29)/2,board_z))
checks['esp32_mm']=[52,29]
checks['altura_disponivel_sobre_apoios_mm']=round(board_height,2)
checks['interferencia_envelope_esp32_mm3']=board_envelope.common(tray.fuse(shell)).Volume
assert checks['interferencia_envelope_esp32_mm3']<.001, checks
checks['berco_esp32']={'integrado_na_base':True,'apoios':4,
 'elevacao_sobre_fundo_interno_mm':SUPPORT_HEIGHT,'folga_guias_por_lado_mm':GUIDE_CLEARANCE,
 'altura_guias_acima_apoios_mm':GUIDE_EXTRA,'dimensao_nominal_placa_mm':[BOARD_L,BOARD_W],
 'encaixe_livre_sem_trava':True,'posicoes_dos_pinos_nao_medidas':True}
# Placas IR de aproximadamente 20 × 20 mm, em pé na frente.
# Espessura de 1,6 mm é ilustrativa. LED, sensor, pinos e fios NÃO estão
# incluídos nestes volumes; as suas projeções ainda precisam ser medidas.
sensor_refs=[('ReferenciaKY022',SENSOR_LEFT),('ReferenciaKY005',SENSOR_LEFT+SENSOR_SIZE+SENSOR_GAP)]
sensor_shapes=[]
for name,x in sensor_refs:
    sensor=Part.makeBox(SENSOR_SIZE,1.6,SENSOR_SIZE,V(x,6,T+1))
    assert sensor.common(tray.fuse(shell)).Volume<.001,name
    assert sensor.common(board_envelope).Volume<.001,name
    sensor_shapes.append((name,sensor))
assert sensor_shapes[0][1].common(sensor_shapes[1][1]).Volume<.001
checks['modulos_ir']={'placas_aproximadas_mm':[20,20],'orientacao':'em pe na frente',
 'espessura_ilustrativa_mm':1.6,'espaco_entre_placas_mm':SENSOR_GAP,
 'folga_superior_placas_mm':round(H-T-(T+1+20),2),
 'componentes_e_pinos_incluidos':False,'interferencia_placas_referencia_mm3':0.}
# STLs orientados para impressão: exterior de cada peça na mesa.
print_shell=shell.copy()
print_shell.rotate(V(0,W/2,0),V(1,0,0),180)
print_shell.translate(V(0,0,H))
for name,shape in [('base',tray),('tampa',print_shell)]:
    assert shape.isValid() and len(shape.Solids)==1,name
    mesh=MeshPart.meshFromShape(Shape=shape,LinearDeflection=.025,AngularDeflection=.08,Relative=False)
    assert mesh.isSolid(),name
    mesh.write(str(OUT/(name+'.stl')))
    checks[name]={'solido_valido':True,'malha_fechada':True,'volume_mm3':round(shape.Volume,2),'triangulos':mesh.CountFacets}
# Duas amostras pequenas para conferir a tolerância de uma trava antes da caixa.
crop=Part.makeBox(17,8.5,12,V(18,0,0))
for name,shape in [('teste_encaixe_base',tray.common(crop)),
                   ('teste_encaixe_parede',shell.common(crop))]:
    shape=shape.removeSplitter()
    assert shape.isValid() and len(shape.Solids)==1,name
    shape.translate(V(-18,0,-shape.BoundBox.ZMin))
    mesh=MeshPart.meshFromShape(Shape=shape,LinearDeflection=.05,AngularDeflection=.12,Relative=False)
    assert mesh.isSolid(),name
    mesh.write(str(OUT/(name+'.stl')))
checks['amostras_encaixe_stl']=['teste_encaixe_base.stl','teste_encaixe_parede.stl']
# Documento em montagem fechada e uma vista explodida para inspecionar.
name='Caixa_IR_Gree_Mini'
if name in App.listDocuments():
    raise RuntimeError('Feche o documento compacto antes de regenerar para não perder alterações.')
doc=App.newDocument(name)
for name,label,shape in [('Base','Base · berço ESP32 e quatro travas de encaixe',tray),('Tampa','Carcaça superior · encaixe sem parafusos',shell)]:
    obj=doc.addObject('PartDesign::Feature',name)
    obj.Label=label
    obj.Shape=shape.cleaned()
    obj.addProperty('App::PropertyString','Fonte').Fonte='gerar_caixa.py — dimensões ajustáveis no script'
    if App.GuiUp:
        obj.Visibility=True
        obj.ViewObject.ShapeColor=(.62,.035,.13)
        obj.ViewObject.LineColor=(.22,.025,.05)
        obj.ViewObject.DisplayMode='Flat Lines'
        obj.ViewObject.LineWidth=1.
        obj.ViewObject.AngularDeflection=10
        obj.ViewObject.Deviation=.1
sheet=doc.addObject('Spreadsheet::Sheet','Medidas')
for i,(key,val) in enumerate([('Comprimento',L),('Largura',W),('Altura',H),('Parede',T),('Raio',R),('Junta inferior',SEAM),('Folga por lado',GAP)],1):
    sheet.set(f'A{i}',key);sheet.set(f'B{i}',str(val)+' mm')
sheet.setColumnWidth('A',180)
footprint=doc.addObject('PartDesign::Feature','ReferenciaESP32')
footprint.Label='Referência 52 × 29 mm · altura real não informada · não imprimir'
footprint.Shape=Part.makeBox(BOARD_L,BOARD_W,1.6,V(BX,BY,T+SUPPORT_HEIGHT)).cleaned()
if App.GuiUp:
    footprint.ViewObject.ShapeColor=(.1,.45,.25)
    footprint.Visibility=False
for name,shape in sensor_shapes:
    obj=doc.addObject('PartDesign::Feature',name)
    obj.Label=name.replace('Referencia','')+' · placa 20 × 20 mm · não imprimir'
    obj.Shape=shape.cleaned()
    obj.addProperty('App::PropertyString','Observacao').Observacao='Só PCB; altura dos componentes e pinos não medida; espessura ilustrativa.'
    if App.GuiUp:
        obj.ViewObject.ShapeColor=(.15,.35,.2)
        obj.Visibility=False
doc.recompute()
Import.export([doc.getObject('Base'),doc.getObject('Tampa')],str(OUT/'caixa_ir_gree_mini.step'))
if App.GuiUp:
    import FreeCADGui as Gui
    Gui.activeDocument().activeView().viewAxonometric()
    Gui.activeDocument().activeView().fitAll()
doc.recompute()
doc.saveAs(str(OUT/'caixa_ir_gree_mini.FCStd'))
(OUT/'validacao.json').write_text(json.dumps(checks,indent=2)+'\n')
print(json.dumps(checks,indent=2))
