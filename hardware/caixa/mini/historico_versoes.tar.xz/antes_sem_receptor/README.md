# Caixa mini — 64 × 45 × 32,9 mm

## Imprimir

Os STL já estão orientados e não precisam de suportes. PLA, bico 0,4 mm,
camada 0,2 mm, 4 perímetros, 15–20% de preenchimento e ventoinha ligada.

1. `teste_encaixe_base.stl` + `teste_encaixe_parede.stl` (minutos): encaixe
   a parede na base. Se a trava ficar dura demais ou frouxa, ajuste as
   constantes `SNAP_*` ou `GAP` e gere de novo.
2. `base.stl`: fundo na mesa.
3. `tampa.stl`: topo na mesa.

A tolerância já cobre placas KY-005 de 14 a 16 mm de largura e pinos do
ESP32 que descem até 9,5 mm. Fios dos módulos: solde-os direto, porque
conectores Dupont não cabem atrás do emissor.

Versão menor para ESP32 de 52 × 29 mm, receptor IR e emissor IR com seu
pequeno circuito de transistor e resistores. Sem expansão de terminais,
protoboard ou Arduino de testes.

Os módulos são os Keyes KY-022 (receptor VS1838B) e KY-005 (emissor), com
pinos em ângulo reto saindo por uma borda da placa. O receptor tem a face
óptica normal à placa, enquanto o LED do KY-005 aponta paralelo à placa,
na borda oposta aos pinos. Para ambos olharem para a frente da caixa:

- o **receptor** fica em pé, encaixado numa canaleta no fundo da base, com
  os pinos para cima;
- o **emissor** fica deitado acima do ESP32, deslizando em dois trilhos
  presos ao teto da carcaça.

Há 22 mm entre os centros dos furos frontais. As referências incluem
somente as placas, com espessura de 1,6 mm. As formas ópticas são
aproximações para mostrar a direção correta. Veja `previa_interna.png`.

Abra `caixa_ir_gree_mini.FCStd` no FreeCAD. Os STL `base.stl` e `tampa.stl`
são as peças imprimíveis, em milímetros, já orientadas para a impressão.
`caixa_ir_gree_mini.step` contém a montagem fechada. `previa.png` e
`previa_traseira.png` são renderizações das malhas STL reais, produzidas por
`render_vtk.py` (renderização com iluminação e profundidade) ou
`render_previa.py` (alternativa com Matplotlib); eventual imagem de montagem interna gerada por IA é
apenas uma proposta ilustrativa, não comprovação de encaixe ou esquema elétrico.
As versões anteriores da mini estão em `historico_versoes.tar.xz`, cada
uma numa pasta `antes_*`; a mais recente é `antes_quadrada`, com os cantos
redondos de 14 mm.

## Construção

- Paredes e fundo de 2,4 mm; visual mais quadrado, com cantos externos de
  raio 6 mm (constante `R`).
- Borda superior arredondada em 2 mm e inferior em 1,2 mm (`TOP_ROUND` e
  `BOTTOM_ROUND`). Rebaixo frontal
  mais discreto, com transição de raio 0,2 mm. STL com malha refinada para
  representar as curvas com menor facetamento. As bordas da junta receberam
  raio de 0,05 mm; as bocas dos furos ópticos, 0,15 mm. A boca do USB foi
  suavizada em 0,2 mm, mantendo as dimensões internas do recorte.
- Fechamento por quatro linguetas de encaixe ocultas na saia da base,
  duas na frente e duas atrás. Sem parafusos ou torres de fixação.
- Cada lingueta tem trecho flexível de 12 mm, espessura de 1 mm e dente
  com rampas superior e inferior. Projeção de 0,6 mm; deslocamento nominal
  para entrada de 0,3 mm. Os dentes se alojam em cavidades internas da
  carcaça, sem furos externos para as travas.
- A saia usa folga lateral de 0,3 mm por lado. As bordas de fechamento
  encostam em z=8 mm, sem o vão vertical de 0,25 mm da versão anterior.
  O pequeno raio de 0,05 mm suaviza a junta sem criar uma canaleta larga.
- Berço integrado à base para o ESP32 com a barra de pinos soldada para
  baixo: quatro apoios de 9,5 mm sob as pontas da placa, fora das fileiras
  de pinos. Os pinos descem ~8,5 mm (espaçador de 2,5 mm + ~6 mm de pino)
  e ficam 1 mm acima do fundo (`PIN_DROP`). Guias com folga de 0,35 mm
  por lado e batentes; a placa apoia livremente, sem travas. A altura da
  caixa, o USB e os furos ópticos são calculados a partir dessa elevação.
- Canaleta do receptor no fundo da base: ranhura de 1,9 mm (PCB de 1,6 mm
  com 0,15 mm de folga por lado), 3 mm de profundidade e 22 mm de
  comprimento, aberta nas pontas. Aceita placas de qualquer largura até
  22 mm. O receptor entra com os pinos para cima; a borda frontal do ESP32
  e a parede da frente impedem que ele tombe.
- Trilhos do emissor no teto da carcaça: duas ranhuras de 1,9 mm que
  seguram 0,8 mm de cada borda lateral da PCB do KY-005. A placa entra por
  trás, com o LED à frente, até a aba do LED encostar no furo frontal.
  Os trilhos foram desenhados para a medida de catálogo de 15 × 18,5 mm
  (`EMITTER_PCB_W` e `EMITTER_PCB_D`). Como crescem a partir do teto,
  imprimem sem suporte junto com a carcaça.
- Fundo liso e contínuo, totalmente fechado. Sem furos de parafusos,
  passagens para abraçadeiras ou rebaixos para pés.
- Topo inteiramente liso, sem fendas ou símbolo gravado.
- Sete fendas arredondadas na parede traseira, com 2,4 × 8 mm cada,
  começando a 12 mm do fundo. Os intervalos entre elas medem 1,4 mm.
- Frente rebaixada em 0,5 mm, com somente dois furos circulares simples:
  um de 5,5 mm para o receptor, centralizado em x=21 mm, e um de 5,2 mm
  para o emissor, em x=43 mm. Ambos estão a 25 mm do fundo, em uma proposta
  de alinhamento que ainda precisa das medidas reais dos módulos. O furo do
  receptor substitui a antiga abertura alongada. Os diâmetros ainda precisam
  ser conferidos com as faces ópticas dos componentes comprados.
- Passagem para o micro-USB do próprio ESP32 na lateral curta direita, ao
  olhar de frente para os sensores: janela de 12 × 9 mm com cantos de raio
  1,5 mm, centralizada no conector (14,9 mm do fundo). A borracha do plugue
  entra na caixa até a ponta da placa, por isso a passagem também recorta
  a saia da base e o trecho central das guias. Monte o ESP32 com o USB
  virado para esse lado.
  A traseira tem somente
  as fendas de ventilação.

## O que já foi confirmado

O envelope retangular de 52 × 29 mm, centralizado acima dos apoios, fica
livre das paredes, saia e guias. Há cerca de 7,8 mm de altura livre entre
a face inferior da PCB do ESP32 e os trilhos do emissor. Base e carcaça são sólidos únicos válidos, sem interferência
entre elas; as duas malhas STL são fechadas. Resultados em `validacao.json`.
As faces das bordas estão em contato; foram conferidos a área de assentamento
e os contornos externos em seções acima e abaixo da junta. A tampa e a base
têm posições sem deslocamento no documento de montagem. Isso não substitui
o teste físico de tolerância das travas na impressora.
A seção do fundo foi conferida: somente o contorno externo, sem furos.
Os dentes ficam livres nas cavidades quando fechados; foi conferido o
espaço de entrada com deslocamento radial nominal de 0,31 mm. Isso é uma
verificação geométrica e não uma simulação mecânica da flexão do PLA.
Veja `previa_fundo.png` e `previa_apoio.png`.

A altura real da placa com seus conectores não foi informada. O receptor,
o circuito emissor e o percurso do cabo ainda precisam de conferência física.
As referências IR não colidem com a caixa nem com a referência da PCB do
ESP32 de 1,6 mm. O emissor deitado tem sua PCB a 20,9 mm do fundo, com
6,2 mm entre a face superior da PCB do ESP32 e os trilhos, espaço para o
módulo blindado (~3,2 mm). O gerador confirma que um plugue micro-USB com
borracha de 11 × 7,5 mm alcança o conector sem tocar na caixa e que as
fileiras de pinos para baixo não encostam em nada.
O gerador confirma que as duas placas ficam presas: deslocar o receptor ou
o emissor 0,4 mm para qualquer lado faz a placa encontrar a canaleta ou o
trilho. Isso não valida o alinhamento exato da face óptica com os furos.

**Antes de imprimir, meça com paquímetro:**

- largura (borda do LED) e profundidade da PCB do KY-005: os trilhos só
  seguram a placa se ela tiver 15 mm de largura, com tolerância de ±0,15 mm;
- se há componentes ou solda a menos de 1 mm das bordas laterais do
  KY-005, onde os trilhos encostam;
- quanto os pinos do ESP32 descem abaixo da placa, contando o espaçador
  plástico: o projeto supõe 8,5 mm (`PIN_DROP`);
- a borracha do seu cabo micro-USB: a passagem aceita até ~11,5 × 8,5 mm;
- o comprimento dos pinos do KY-005: com conectores Dupont, eles passam do
  fundo da caixa. Solde os fios direto nos pinos ou corte-os.
A passagem supõe o conector centralizado na ponta curta da placa, rente à
borda, como no ESP32 DevKit V1.

## Impressão

Ponto de partida: PLA, bico 0,4 mm, camada 0,20 mm, quatro perímetros,
cinco camadas de topo/fundo e 15–20% de preenchimento. Use as temperaturas
do fabricante. Base com fundo na mesa; carcaça com topo externo na mesa,
conforme orientação já salva no STL. Confira primeira camada e pequenas
pontes dos furos no fatiador. Não foi feita impressão de teste.

Antes da caixa completa, imprima `teste_encaixe_base.stl` e
`teste_encaixe_parede.stl`: são um trecho da base e da parede com uma trava,
para conferir o ajuste na sua impressora. As faces externas dessas amostras
ficam alinhadas durante o teste; a parede desliza por fora da saia da base.
As amostras verificam a tolerância local, não a força total das quatro travas.
Confira os pequenos vãos das linguetas e a região das rampas no fatiador;
evite suportes dentro dos vãos das travas. A base imprime com o fundo na mesa.

Montagem: encaixe o ESP32 no berço e o receptor na canaleta, com os pinos
para cima. Com a carcaça de cabeça para baixo, deslize o emissor pelos
trilhos até o LED entrar no furo. Feche alinhando a saia e pressionando os
quatro pontos até assentarem.
Para abrir, separe gradualmente pela junta, sem torcer uma lingueta isolada.
As rampas de saída ajudam a soltar, mas a retenção e a resistência a aberturas
repetidas ainda precisam de ensaio físico. O encaixe foi pensado para abertura
ocasional. As dimensões das linguetas ficam nas constantes `SNAP_*` do gerador.

Os anúncios enviados mostram KY-022/VS1838B e KY-005. A medida de
7,4 × 6,4 × 5,1 mm do anúncio do receptor parece descrever o encapsulamento
do sensor; não foi adotada como dimensão da placa inteira. A referência
do receptor mantém os 20 × 20 mm aproximados, já que a canaleta aceita
qualquer largura; a do emissor usa a medida de catálogo de 15 × 18,5 mm.
Os furos de 5,5 e 5,2 mm são previsões para expor a parte óptica, sem passar
a placa ou o corpo inteiro. Ainda precisam de conferência física.

A planilha no FreeCAD é uma referência. Para regenerar, altere as constantes
em `gerar_caixa.py` e execute `python hardware/caixa/mini/gerar_caixa.py`.
As referências verdes do ESP32 e dos dois módulos IR são ilustrativas e
devem permanecer fora do fatiamento. Oculte a carcaça e mostre essas
referências na árvore do FreeCAD para examinar a proposta interna.
