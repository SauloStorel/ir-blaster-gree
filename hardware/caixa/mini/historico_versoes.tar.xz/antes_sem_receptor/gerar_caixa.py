"""Caixa mini: ESP32 de 52 × 29 mm com pinos para baixo, micro-USB próprio na lateral direita."""
import sys, json, tempfile
from pathlib import Path
sys.path.insert(0, '/usr/lib/freecad/lib')
import FreeCAD as App
import Part, MeshPart, Import
V=App.Vector
OUT=Path(__file__).resolve().parent
L,W=64.,45.
T=2.4
# Visual mais quadrado: cantos e bordas com raios pequenos.
R=6.
TOP_ROUND, BOTTOM_ROUND = 2., 1.2
SEAM=8.
GAP=.3
JOINT_GAP=0.
BOARD_L, BOARD_W = 52., 29.
# ESP32 com barra de pinos soldada para baixo: espaçador de 2,5 mm + ~6 mm de pino.
# Os apoios deixam 1 mm entre a ponta dos pinos e o fundo; o resto da caixa sobe junto.
PIN_DROP=8.5
SUPPORT_HEIGHT, GUIDE_CLEARANCE, GUIDE_EXTRA = PIN_DROP+1., .35, 2.5
H=SUPPORT_HEIGHT+23.4
BX, BY = (L-BOARD_L)/2, (W-BOARD_W)/2
SENSOR_SIZE, SENSOR_GAP = 20., 2.
SENSOR_LEFT=(L-(2*SENSOR_SIZE+SENSOR_GAP))/2
RECEIVER_X=SENSOR_LEFT+SENSOR_SIZE/2
EMITTER_X=RECEIVER_X+SENSOR_SIZE+SENSOR_GAP
OPTIC_Z=SUPPORT_HEIGHT+15.5
EMITTER_PCB_Z=OPTIC_Z-2.5-1.6
# Keyes KY-005: medida de catálogo, LED na borda de 15 mm e pinos na oposta.
# Os trilhos aceitam ±1 mm na largura, porque a medida ainda não foi conferida.
EMITTER_PCB_W, EMITTER_PCB_D = 15., 18.5
PCB_T, SLOT_CLEARANCE = 1.6, .15
RECEIVER_PCB_Y=6.
RECEIVER_PCB_Z=OPTIC_Z-17.1

def rr(l,w,h,r,x=0,y=0,z=0):
    b=Part.makeBox(l,w,h,V(x,y,z))
    return b.makeFillet(r,[e for e in b.Edges if e.BoundBox.ZLength>h-.001])

def edge_round(s,z,r):
    return s.makeFillet(r,[e for e in s.Edges if abs(e.BoundBox.ZMin-z)<1e-5 and abs(e.BoundBox.ZMax-z)<1e-5])

# Todos os sólidos são construídos primeiro na posição de montagem.
outer=edge_round(rr(L,W,H-SEAM,R,z=SEAM),H,TOP_ROUND)
outer=edge_round(outer,SEAM,.05)
shell=outer.cut(rr(L-2*T,W-2*T,H-T+1,R-T,T,T,-1))
tray=edge_round(rr(L,W,SEAM-JOINT_GAP,R),0,BOTTOM_ROUND)
tray=edge_round(tray,SEAM-JOINT_GAP,.05)
tray=tray.cut(rr(L-2*T,W-2*T,H,R-T,T,T,T))
# As bordas externas encostam em z=8; a folga de 0,3 mm fica só na saia interna.
inset=T+GAP
lip=rr(L-2*inset,W-2*inset,3.3,R-inset,inset,inset,SEAM-.2)
lip=lip.cut(rr(L-2*(inset+1.6),W-2*(inset+1.6),5,R-inset-1.6,inset+1.6,inset+1.6,SEAM-1))
# Degrau interno desce até o fundo: sem balanço sob a saia na impressão.
shoulder=rr(L-3.8,W-3.8,SEAM-.05-T,R-1.9,1.9,1.9,T)
shoulder=shoulder.cut(rr(L-2*(inset+1.6),W-2*(inset+1.6),SEAM,R-inset-1.6,inset+1.6,inset+1.6,T-1))
lip=lip.fuse(shoulder)
tray=tray.fuse(lip)
# Quatro linguetas horizontais flexíveis na saia, com dentes rampados.
# Sem torres ou furos de parafuso. Cavidades ficam ocultas na parede interna.
SNAP_LENGTH, SNAP_THICKNESS, SNAP_PROJECTION = 12., 1., .6
snap_teeth=[]
snap_pockets=[]
for rear in (False,True):
    for x in (20.,42.):
        # Cada lingueta fica presa somente pela extremidade x+12.
        outer_y=inset if not rear else W-inset-1.6
        bottom_slot=Part.makeBox(SNAP_LENGTH+.5,1.8,.95,V(x-.5,outer_y-.1,7.25))
        tip_slot=Part.makeBox(.55,1.8,4,V(x-.55,outer_y-.1,7.2))
        relief_y=inset+SNAP_THICKNESS if not rear else W-inset-1.7
        inner_relief=Part.makeBox(SNAP_LENGTH,.7,3.2,V(x,relief_y,8.15))
        tray=tray.cut(bottom_slot).cut(tip_slot).cut(inner_relief)
        # Rampas superior e inferior permitem encaixar e soltar com cuidado.
        profile=[(inset,8.8),(inset-SNAP_PROJECTION,9.2),
                 (inset-SNAP_PROJECTION,9.5),(inset,10.7)]
        points=[V(x+1,W-y if rear else y,z) for y,z in profile]
        points.append(points[0])
        tooth=Part.Face(Part.makePolygon(points)).extrude(V(4,0,0))
        tray=tray.fuse(tooth)
        snap_teeth.append(tooth)
        pocket_y=W-2.5 if rear else 1.6
        pocket=Part.makeBox(4.6,.9,2.7,V(x+.7,pocket_y,8.5))
        shell=shell.cut(pocket)
        snap_pockets.append(pocket)
# Frente: rebaixo externo raso e somente um furo circular por sensor.
# Cápsulas no plano XZ, extrudadas em Y.
def front_slot(width,height,depth,x,z,y=-1):
    s=rr(width,height,depth,height/2-.01)
    s.rotate(V(),V(1,0,0),90)
    s.translate(V(x,y+depth,z))
    return s
shell=shell.cut(front_slot(38,8,1.5,(L-38)/2,OPTIC_Z-4))
RECEIVER_DIAMETER, EMITTER_DIAMETER = 5.5, 5.2
shell=shell.cut(Part.makeCylinder(RECEIVER_DIAMETER/2,5,V(RECEIVER_X,-1,OPTIC_Z),V(0,1,0)))
shell=shell.cut(Part.makeCylinder(EMITTER_DIAMETER/2,5,V(EMITTER_X,-1,OPTIC_Z),V(0,1,0)))
# Transição suave somente no contorno do rebaixo; os furos continuam simples.
panel_edges=[e for e in shell.Edges if abs(e.BoundBox.YMin-.5)<1e-6
             and abs(e.BoundBox.YMax-.5)<1e-6
             and (e.BoundBox.XMin<(L-38)/2+.01
                  or e.BoundBox.XMax>(L+38)/2-.01
                  or e.BoundBox.ZMin<OPTIC_Z-3.99 or e.BoundBox.ZMax>OPTIC_Z+3.99)]
assert len(panel_edges)==8
shell=shell.makeFillet(.2,panel_edges)
optic_edges=[e for e in shell.Edges if abs(e.BoundBox.YMin-.5)<1e-6
             and abs(e.BoundBox.YMax-.5)<1e-6
             and (abs(e.BoundBox.XLength-RECEIVER_DIAMETER)<1e-5
                  or abs(e.BoundBox.XLength-EMITTER_DIAMETER)<1e-5)]
assert len(optic_edges)==2
shell=shell.makeFillet(.15,optic_edges)
# Micro-USB nativo do ESP32, na ponta direita da placa ao olhar para os sensores.
# A borracha do plugue (~11 × 7,5 mm) entra 6 mm até a ponta da placa, então a
# passagem atravessa parede, junta e saia da base, e corta o trecho central das guias.
USB_WIDTH, USB_HEIGHT, USB_CENTER_Y = 12., 9., W/2
USB_CENTER_Z=T+SUPPORT_HEIGHT+PCB_T+1.4  # receptáculo micro-USB de ~2,8 mm sobre a PCB
USB_BOTTOM=USB_CENTER_Z-USB_HEIGHT/2
USB_START_X=BX+BOARD_L+.3
usb_cut=rr(USB_WIDTH,USB_HEIGHT,L+1-USB_START_X,1.5)
usb_cut.rotate(V(),V(1,1,1),120)
usb_cut.translate(V(USB_START_X,USB_CENTER_Y-USB_WIDTH/2,USB_BOTTOM))
def round_usb_mouth(part):
    edges=[e for e in part.Edges if abs(e.BoundBox.XMin-L)<1e-6
           and abs(e.BoundBox.XMax-L)<1e-6
           and e.BoundBox.YMin>USB_CENTER_Y-USB_WIDTH/2-.01
           and e.BoundBox.YMax<USB_CENTER_Y+USB_WIDTH/2+.01
           and e.BoundBox.ZMin>USB_BOTTOM-.01
           and e.BoundBox.ZMax<USB_BOTTOM+USB_HEIGHT+.01
           and e.BoundBox.ZLength+e.BoundBox.YLength>.5]
    assert edges
    return part.makeFillet(.2,edges)
shell=round_usb_mouth(shell.cut(usb_cut))
# Topo inteiramente liso; sete fendas verticais na parede traseira, acima da saia.
VENT_WIDTH, VENT_HEIGHT, VENT_BOTTOM, VENT_PITCH = 2.4, 8., 12., 3.8
vent_centers=[]
for i in range(7):
    x=L/2+(i-3)*VENT_PITCH
    vent_centers.append(x)
    vent=rr(VENT_WIDTH,VENT_HEIGHT,5,1.19)
    vent.rotate(V(),V(1,0,0),90)
    vent.translate(V(x-VENT_WIDTH/2,W+1,VENT_BOTTOM))
    shell=shell.cut(vent)
# Trilhos no teto para a PCB do emissor deitada: ela entra por trás até a aba
# do LED encostar no furo frontal. Crescem a partir do teto, sem suportes na impressão.
# Folga lateral de 1 mm e apoio de 1 mm por borda: servem placas de 14 a 16 mm.
RAIL_WIDTH, RAIL_OVERLAP, RAIL_PLAY, RAIL_Y = 1.2, 1., 1., 9.
RAIL_LENGTH=EMITTER_PCB_D-3
RAIL_BOTTOM=EMITTER_PCB_Z-1.2
for side in (-1,1):
    edge=EMITTER_X+side*EMITTER_PCB_W/2
    inner=edge-side*RAIL_OVERLAP
    groove_bottom=edge+side*RAIL_PLAY
    outer_face=groove_bottom+side*RAIL_WIDTH
    rail=Part.makeBox(abs(outer_face-inner),RAIL_LENGTH,H-T-RAIL_BOTTOM+.5,
                      V(min(inner,outer_face),RAIL_Y,RAIL_BOTTOM))
    groove=Part.makeBox(abs(groove_bottom-inner),RAIL_LENGTH+2,PCB_T+2*SLOT_CLEARANCE,
                        V(min(inner,groove_bottom),RAIL_Y-1,EMITTER_PCB_Z-SLOT_CLEARANCE))
    shell=shell.fuse(rail.cut(groove))
# Fundo contínuo: sem passagens de abraçadeira ou rebaixos para pés.
# Berço integrado à base: quatro apoios sob as extremidades da PCB, fora das barras de pinos.
# Centro e faixas dos headers ficam livres; as posições dos pinos são desconhecidas.
for x in (BX+.5, BX+BOARD_L-3.5):
    for y in (15.,26.):
        tray=tray.fuse(rr(3,4,SUPPORT_HEIGHT,.6,x,y,T))
# Guias laterais com folga, abertas no meio para não bloquear o USB da placa.
guide_height=SUPPORT_HEIGHT+GUIDE_EXTRA
for x in (BX-GUIDE_CLEARANCE-1.5,BX+BOARD_L+GUIDE_CLEARANCE):
    for y in (14.,25.):
        tray=tray.fuse(rr(1.5,6,guide_height,.7,x,y,T))
# Batentes frontais fora das placas IR de 20 × 20 mm.
for x in (BX+1,BX+BOARD_L-4):
    tray=tray.fuse(rr(3,1.5,guide_height,.7,x,BY-GUIDE_CLEARANCE-1.5,T))
for x in (BX+15,BX+36):
    tray=tray.fuse(rr(6,1.5,guide_height,.7,x,BY+BOARD_W+GUIDE_CLEARANCE,T))
# Canaleta para a PCB do receptor em pé, com os pinos para cima.
# Aberta nas pontas, aceita placas de até 22 mm; fica abaixo do ESP32.
RIB_LENGTH, SLOT_DEPTH = 22., 3.
slot_front=RECEIVER_PCB_Y-SLOT_CLEARANCE
slot_back=RECEIVER_PCB_Y+PCB_T+SLOT_CLEARANCE
rib=Part.makeBox(RIB_LENGTH,slot_back+.75-(slot_front-1.2),RECEIVER_PCB_Z+SLOT_DEPTH-T,
                 V(RECEIVER_X-RIB_LENGTH/2,slot_front-1.2,T))
rib=rib.cut(Part.makeBox(RIB_LENGTH+2,slot_back-slot_front,SLOT_DEPTH+1,
                         V(RECEIVER_X-RIB_LENGTH/2-1,slot_front,RECEIVER_PCB_Z)))
tray=tray.fuse(rib)
tray=tray.cut(usb_cut)
tray=tray.removeSplitter()
shell=shell.removeSplitter()
checks={'interferencia_mm3':tray.common(shell).Volume,'dimensoes_externas_mm':[L,W,H],
        'microusb_lateral_direita':{'face':f'x={L:g}','centro_y_mm':USB_CENTER_Y,
        'largura_mm':USB_WIDTH,'altura_mm':USB_HEIGHT,'altura_inferior_mm':USB_BOTTOM,
        'centro_z_mm':USB_CENTER_Z,'usb_nativo_esp32':True},'abertura_usb_frontal':False,'abertura_cabo_traseira':False,
        'topo_liso':True,'ventilacao_traseira':{'quantidade':7,'largura_mm':VENT_WIDTH,
        'altura_mm':VENT_HEIGHT,'altura_inferior_mm':VENT_BOTTOM},
        'aberturas_ir_frontais':{'quantidade':2,'rebaixo_compartilhado':True,
        'profundidade_rebaixo_mm':.5,'receptor_diametro_mm':RECEIVER_DIAMETER,
        'emissor_diametro_mm':EMITTER_DIAMETER,'distancia_centros_mm':EMITTER_X-RECEIVER_X,
        'altura_eixos_mm':OPTIC_Z},
        'acabamento':{'raio_cantos_mm':R,'raio_borda_superior_mm':TOP_ROUND,
        'raio_borda_inferior_mm':BOTTOM_ROUND,'raio_rebaixo_mm':.2,'junta_mm':JOINT_GAP,
        'raio_bordas_junta_mm':.05,'raio_boca_furos_ir_mm':.15,'raio_boca_usb_mm':.2}}
checks['fundo']={'furos_parafusos':0,'passagens_abracadeiras':0,'rebaixos_pes':0,
 'espessura_mm':T}
checks['fechamento']={'tipo':'encaixe com linguetas rampadas','travas':4,
 'comprimento_flexivel_mm':SNAP_LENGTH,'espessura_lingueta_mm':SNAP_THICKNESS,
 'projecao_dente_mm':SNAP_PROJECTION,'deflexao_nominal_montagem_mm':SNAP_PROJECTION-GAP,
 'ensaio_fisico_realizado':False}
# A seção próxima da face externa deve ser um único contorno sem furos.
bottom_wires=tray.slice(V(0,0,1),.1)
assert len(bottom_wires)==1 and bottom_wires[0].isClosed()
for tooth,pocket in zip(snap_teeth,snap_pockets):
    assert tooth.common(shell).Volume<.001
    assert tooth.common(pocket).Volume>.01
# Comprova a folga nominal de entrada dos dentes com deslocamento radial.
for i,tooth in enumerate(snap_teeth):
    flexed=tooth.copy()
    flexed.translate(V(0,-.31 if i>=2 else .31,0))
    for offset in (-4.,-2.,0.):
        moved=flexed.copy()
        moved.translate(V(0,0,offset))
        assert moved.common(shell).Volume<.001
assert checks['interferencia_mm3']<.001, checks
# Fechamento assentado: faces de apoio em contato, contornos exteriores alinhados.
contact=tray.common(shell)
def seating_faces(part):
    return [f for f in part.Faces if abs(f.BoundBox.ZMin-SEAM)<1e-6
            and abs(f.BoundBox.ZMax-SEAM)<1e-6]
contact_area=sum(a.common(b).Area for a in seating_faces(tray) for b in seating_faces(shell))
assert contact_area>100 and contact.Volume<.001
footprints=[]
for part,z in ((tray,SEAM-.3),(shell,SEAM+.3)):
    wire=max(part.slice(V(0,0,1),z),key=lambda w:w.BoundBox.XLength*w.BoundBox.YLength)
    b=wire.BoundBox
    footprint=[b.XMin,b.YMin,b.XMax,b.YMax]
    assert max(abs(a-b) for a,b in zip(footprint,(0,0,L,W)))<1e-5
    footprints.append(footprint)
checks['assentamento']={'area_contato_mm2':round(contact_area,2),
 'folga_vertical_bordas_mm':JOINT_GAP,'folga_lateral_saia_mm':GAP,
 'contornos_externos_alinhados':True}
assert not shell.isInside(V(L-T/2,USB_CENTER_Y,USB_CENTER_Z),1e-6,True)
# Plugue micro-USB encaixado: borracha de 11 × 7,5 mm encostada na ponta da placa.
plug=Part.makeBox(15,11,7.5,V(BX+BOARD_L+.5,USB_CENTER_Y-5.5,USB_CENTER_Z-3.75))
assert plug.common(tray.fuse(shell)).Volume<.001, 'Plugue micro-USB não alcança o ESP32'
assert shell.isInside(V(L/2,T/2,OPTIC_Z),1e-6,True), 'Material deve separar os dois sensores'
assert shell.isInside(V(T/2,W/2,12),1e-6,True), 'Lateral esquerda deve estar fechada'
# Confere a continuidade do topo plano e a abertura efetiva das fendas traseiras.
roof_probe=Part.makeBox(L-2*R,W-2*R,.3,V(R,R,H-.3))
assert abs(roof_probe.common(shell).Volume-roof_probe.Volume)<.001
for x in vent_centers:
    assert not shell.isInside(V(x,W-T/2,VENT_BOTTOM+VENT_HEIGHT/2),1e-6,True)
# Envelope retangular acima dos apoios, até os trilhos do emissor.
# Só comprimento/largura foram medidos; a altura é a capacidade disponível.
board_z=T+SUPPORT_HEIGHT+.01
board_height=RAIL_BOTTOM-board_z-.01
board_envelope=Part.makeBox(52,29,board_height,V((L-52)/2,(W-29)/2,board_z))
checks['esp32_mm']=[52,29]
checks['altura_livre_sob_trilhos_emissor_mm']=round(board_height,2)
checks['interferencia_envelope_esp32_mm3']=board_envelope.common(tray.fuse(shell)).Volume
# Barras de pinos para baixo, nas bordas longas: 25,4 mm entre as fileiras.
pin_rows=[Part.makeBox(BOARD_L,2.5,PIN_DROP,V(BX,y-1.25,board_z-PIN_DROP))
          for y in (W/2-12.7,W/2+12.7)]
checks['pinos_esp32_para_baixo']={'comprimento_abaixo_da_pcb_mm':PIN_DROP,
 'folga_ate_o_fundo_mm':round(SUPPORT_HEIGHT-PIN_DROP,2),
 'interferencia_mm3':sum(r.common(tray).Volume for r in pin_rows)}
assert checks['pinos_esp32_para_baixo']['interferencia_mm3']<.001, checks
assert checks['interferencia_envelope_esp32_mm3']<.001, checks
checks['berco_esp32']={'integrado_na_base':True,'apoios':4,
 'elevacao_sobre_fundo_interno_mm':SUPPORT_HEIGHT,'folga_guias_por_lado_mm':GUIDE_CLEARANCE,
 'altura_guias_acima_apoios_mm':GUIDE_EXTRA,'dimensao_nominal_placa_mm':[BOARD_L,BOARD_W],
 'encaixe_livre_sem_trava':True,'posicoes_dos_pinos_nao_medidas':True}
# Orientação correta das fotos: KY-022 normal à PCB, KY-005 paralelo à PCB.
# Para olhar pela frente: receptor em pé, emissor deitado acima do ESP32.
# Formas ópticas ilustrativas; posição exata e pinos não medidos.
esp_pcb=Part.makeBox(BOARD_L,BOARD_W,1.6,V(BX,BY,T+SUPPORT_HEIGHT))
receiver_pcb=Part.makeBox(SENSOR_SIZE,PCB_T,SENSOR_SIZE,V(SENSOR_LEFT,RECEIVER_PCB_Y,RECEIVER_PCB_Z))
emitter_pcb=Part.makeBox(EMITTER_PCB_W,EMITTER_PCB_D,PCB_T,
                         V(EMITTER_X-EMITTER_PCB_W/2,8.5,EMITTER_PCB_Z))
receiver_body=Part.makeBox(7.4,3.5,6.4,V(RECEIVER_X-3.7,2.6,OPTIC_Z-3.2))
receiver_lens=Part.makeSphere(2.5,V(RECEIVER_X,2.7,OPTIC_Z))
receiver_ref=receiver_pcb.fuse(receiver_body).fuse(receiver_lens)
emitter_led=Part.makeCylinder(2.5,5.8,V(EMITTER_X,2.7,OPTIC_Z),V(0,1,0)).fuse(
    Part.makeSphere(2.5,V(EMITTER_X,2.7,OPTIC_Z)))
emitter_ref=Part.makeCompound([emitter_pcb,emitter_led])
sensor_shapes=[('ReferenciaKY022',receiver_ref),('ReferenciaKY005',emitter_ref)]
for name,sensor in sensor_shapes:
    assert sensor.common(tray.fuse(shell)).Volume<.001,name
    assert sensor.common(esp_pcb).Volume<.001,name
assert sensor_shapes[0][1].common(sensor_shapes[1][1]).Volume<.001
# As placas ficam presas: qualquer deslocamento de 0,4 mm encontra canaleta ou trilho.
def held(pcb,part,axis):
    for offset in (-.4,.4):
        moved=pcb.copy()
        moved.translate(axis*offset)
        assert moved.common(part).Volume>.01
held(receiver_pcb,tray,V(0,1,0))
held(emitter_pcb,shell,V(0,0,1))
for width in (EMITTER_PCB_W-1,EMITTER_PCB_W+1):
    pcb=Part.makeBox(width,EMITTER_PCB_D,PCB_T,V(EMITTER_X-width/2,8.5,EMITTER_PCB_Z))
    assert pcb.common(shell).Volume<.001, f'PCB de {width} mm não entra nos trilhos'
    held(pcb,shell,V(0,0,1))
checks['suporte_receptor']={'tipo':'canaleta no fundo, aberta nas pontas','pinos':'para cima',
 'largura_maxima_pcb_mm':RIB_LENGTH,'profundidade_mm':SLOT_DEPTH,
 'folga_por_lado_mm':SLOT_CLEARANCE}
checks['suporte_emissor']={'tipo':'trilhos no teto da carcaça, entrada por trás',
 'pcb_catalogo_mm':[EMITTER_PCB_W,EMITTER_PCB_D],'apoio_por_borda_mm':RAIL_OVERLAP,
 'larguras_aceitas_mm':[EMITTER_PCB_W-1,EMITTER_PCB_W+1],
 'folga_vertical_mm':SLOT_CLEARANCE,'comprimento_trilhos_mm':RAIL_LENGTH,'medida_confirmada':False}
checks['modulos_ir']={'pcb_receptor_referencia_mm':[SENSOR_SIZE,SENSOR_SIZE],
 'pcb_emissor_referencia_mm':[EMITTER_PCB_W,EMITTER_PCB_D],
 'orientacao_receptor':'PCB vertical, face óptica normal à PCB, voltada para a frente',
 'orientacao_emissor':'PCB horizontal elevada, LED paralelo à PCB, voltado para a frente',
 'espessura_ilustrativa_mm':1.6,'espaco_entre_placas_mm':SENSOR_GAP,
 'folga_superior_placas_mm':round(H-T-(RECEIVER_PCB_Z+SENSOR_SIZE),2),
 'altura_pcb_emissor_mm':EMITTER_PCB_Z,
 'folga_entre_pcb_esp32_e_pcb_emissor_mm':round(EMITTER_PCB_Z-(T+SUPPORT_HEIGHT+1.6),2),
 'formas_opticas_ilustrativas':True,'posicoes_opticas_nao_medidas':True,
 'pinos_e_componentes_esp32_nao_modelados':True,'interferencia_referencias_mm3':0.}
# Malhas das referências para render_vtk.py; não são peças de impressão.
visual_dir=Path(tempfile.gettempdir())
for name,shape in [('esp32',esp_pcb),('receptor',receiver_ref),
                   ('emissor_pcb',emitter_pcb),('emissor_led',emitter_led)]:
    MeshPart.meshFromShape(Shape=shape,LinearDeflection=.05,AngularDeflection=.12,
                           Relative=False).write(str(visual_dir/f'ir_visual_{name}.stl'))
# STLs orientados para impressão: exterior de cada peça na mesa.
print_shell=shell.copy()
print_shell.rotate(V(0,W/2,0),V(1,0,0),180)
print_shell.translate(V(0,0,H))
for name,shape in [('base',tray),('tampa',print_shell)]:
    assert shape.isValid() and len(shape.Solids)==1,name
    mesh=MeshPart.meshFromShape(Shape=shape,LinearDeflection=.025,AngularDeflection=.08,Relative=False)
    assert mesh.isSolid(),name
    mesh.write(str(OUT/(name+'.stl')))
    checks[name]={'solido_valido':True,'malha_fechada':True,'volume_mm3':round(shape.Volume,2),'triangulos':mesh.CountFacets}
# Duas amostras pequenas para conferir a tolerância de uma trava antes da caixa.
crop=Part.makeBox(17,8.5,12,V(18,0,0))
for name,shape in [('teste_encaixe_base',tray.common(crop)),
                   ('teste_encaixe_parede',shell.common(crop))]:
    shape=shape.removeSplitter()
    assert shape.isValid() and len(shape.Solids)==1,name
    shape.translate(V(-18,0,-shape.BoundBox.ZMin))
    mesh=MeshPart.meshFromShape(Shape=shape,LinearDeflection=.05,AngularDeflection=.12,Relative=False)
    assert mesh.isSolid(),name
    mesh.write(str(OUT/(name+'.stl')))
checks['amostras_encaixe_stl']=['teste_encaixe_base.stl','teste_encaixe_parede.stl']
# Documento em montagem fechada e uma vista explodida para inspecionar.
name='Caixa_IR_Gree_Mini'
if name in App.listDocuments():
    raise RuntimeError('Feche o documento mini antes de regenerar para não perder alterações.')
doc=App.newDocument(name)
for name,label,shape in [('Base','Base · berço ESP32, canaleta do receptor e quatro travas',tray),('Tampa','Carcaça superior · trilhos do emissor, encaixe sem parafusos',shell)]:
    obj=doc.addObject('PartDesign::Feature',name)
    obj.Label=label
    obj.Shape=shape.cleaned()
    obj.addProperty('App::PropertyString','Fonte').Fonte='gerar_caixa.py — dimensões ajustáveis no script'
    if App.GuiUp:
        obj.Visibility=True
        obj.ViewObject.ShapeColor=(.62,.035,.13)
        obj.ViewObject.LineColor=(.22,.025,.05)
        obj.ViewObject.DisplayMode='Flat Lines'
        obj.ViewObject.LineWidth=1.
        obj.ViewObject.AngularDeflection=10
        obj.ViewObject.Deviation=.1
sheet=doc.addObject('Spreadsheet::Sheet','Medidas')
for i,(key,val) in enumerate([('Comprimento',L),('Largura',W),('Altura',H),('Parede',T),('Raio',R),('Junta inferior',SEAM),('Folga por lado',GAP)],1):
    sheet.set(f'A{i}',key);sheet.set(f'B{i}',str(val)+' mm')
sheet.setColumnWidth('A',180)
footprint=doc.addObject('PartDesign::Feature','ReferenciaESP32')
footprint.Label='Referência 52 × 29 mm · altura real não informada · não imprimir'
footprint.Shape=Part.makeBox(BOARD_L,BOARD_W,1.6,V(BX,BY,T+SUPPORT_HEIGHT)).cleaned()
if App.GuiUp:
    footprint.ViewObject.ShapeColor=(.1,.45,.25)
    footprint.Visibility=False
for name,shape in sensor_shapes:
    obj=doc.addObject('PartDesign::Feature',name)
    obj.Label=name.replace('Referencia','')+(' · receptor em pé' if name.endswith('022') else ' · emissor deitado elevado')+' · não imprimir'
    obj.Shape=shape.cleaned()
    obj.addProperty('App::PropertyString','Observacao').Observacao='Orientação conforme fotos; óptica ilustrativa. Pinos e posição óptica ainda precisam de medidas reais.'
    if App.GuiUp:
        obj.ViewObject.ShapeColor=(.15,.35,.2)
        obj.Visibility=False
doc.recompute()
Import.export([doc.getObject('Base'),doc.getObject('Tampa')],str(OUT/'caixa_ir_gree_mini.step'))
if App.GuiUp:
    import FreeCADGui as Gui
    Gui.activeDocument().activeView().viewAxonometric()
    Gui.activeDocument().activeView().fitAll()
doc.recompute()
doc.saveAs(str(OUT/'caixa_ir_gree_mini.FCStd'))
(OUT/'validacao.json').write_text(json.dumps(checks,indent=2)+'\n')
print(json.dumps(checks,indent=2))
