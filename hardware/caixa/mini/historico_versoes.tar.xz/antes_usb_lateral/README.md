# Caixa mini — 70 × 45 × 25,4 mm

Versão menor para ESP32 de 52 × 29 mm, receptor IR e emissor IR com seu
pequeno circuito de transistor e resistores. Sem expansão de terminais,
protoboard ou Arduino de testes.

Abra `caixa_ir_gree_mini.FCStd` no FreeCAD. Os STL `base.stl` e `tampa.stl`
são as peças imprimíveis, em milímetros, já orientadas para a impressão.
`caixa_ir_gree_mini.step` contém a montagem fechada. `previa.png` é uma
captura real do CAD; eventual imagem de montagem interna gerada por IA é
apenas uma proposta ilustrativa, não comprovação de encaixe ou esquema elétrico.

## Construção

- Paredes e fundo de 2,4 mm; cantos externos de raio 7 mm.
- Duas torres nas extremidades curtas, liberando os cantos para a placa.
- Dois parafusos inferiores ocultos, autoatarraxantes de aproximadamente
  2,9 × 10 mm, cabeça escareada de 90°. Confirme piloto e cabeça antes de montar.
- Passantes de 3,3 mm, pilotos cegos de 2,4 mm e escareados de 6,2 mm.
- A saia usa folga de 0,3 mm por lado e junta externa de 0,35 mm.
- Apoios internos e passagens para abraçadeiras prendem a placa sem presumir
  sua furação. Os apoios elevam o fundo da placa em 1 mm acima do fundo interno.
- Sete fendas graduais no topo e símbolo IR gravado em 0,45 mm.
- Frente com janela arredondada de 14 × 8 mm e furo de 5,4 mm para o LED.

## O que já foi confirmado

O envelope retangular de 52 × 29 mm, centralizado acima dos apoios, fica
livre das paredes, torres e saia. Há cerca de 19,6 mm de altura disponível
acima dos apoios. Base e carcaça são sólidos únicos válidos, sem interferência
entre elas; as duas malhas STL são fechadas. Resultados em `validacao.json`.

A altura real da placa com seus conectores não foi informada. O receptor,
o circuito emissor e o percurso do cabo ainda precisam de conferência física.
Por ser menor, esta versão exige montagem compacta com os componentes IR
junto à parede frontal, possivelmente acima do nível da placa principal.
As aberturas são passagens genéricas e não berços específicos dos módulos.
A saída traseira do cabo não garante alinhamento direto ao USB do ESP32.

## Impressão

Ponto de partida: PLA, bico 0,4 mm, camada 0,20 mm, quatro perímetros,
cinco camadas de topo/fundo e 15–20% de preenchimento. Use as temperaturas
do fabricante. Base com fundo na mesa; carcaça com topo externo na mesa,
conforme orientação já salva no STL. Confira primeira camada e pequenas
pontes dos furos no fatiador. Não foi feita impressão de teste.

A planilha no FreeCAD é uma referência. Para regenerar, altere as constantes
em `gerar_caixa.py` e execute `python hardware/caixa/mini/gerar_caixa.py`.
A referência verde do ESP32 é ilustrativa e deve permanecer fora do fatiamento.
